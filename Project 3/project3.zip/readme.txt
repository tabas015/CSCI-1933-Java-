Compile me with: javac @filesList.txt -d Classes
Run me with: java -cp Classes Main 

Team Members:
* Zachary Smith (smi00903)
	* Primarily worked on LinkedList and ArrayList.
* Fahia Tabassum (tabas015)
	* Primarily worked on ArrayList and the analysis.
