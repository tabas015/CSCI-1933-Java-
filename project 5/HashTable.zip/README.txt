Project 5

1. Group members are-  Ladan Abdi (abdix213) & Fahia Tabassum (tabas015)

2. We actually shared the same algorithm and completed the program together. Specifically, we have helped each other whenever anyone of us has got stuck on something.

3. No, it doesn't have any additional feature.

To compile:
	-check the instructions.txt
	
To run:
	- check the instructions.txt

4. We don't think it has any bug. It was running pretty well.

Credit -> We also used and obtained the TextScan.java file from the CSCI 1933 Spring 2020 Canvas Page.