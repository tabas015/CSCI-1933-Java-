Project 2

1. Group members are-  Fahia Tabassum (tabas015) & Ladan Abdi (abdix213)

2. We actually shared the same algorithm and completed the program together. Specifically, we have helped each other whenever anyone of us has got stuck on something.

3. No, it doesn't have any additional feature.

To compile:
	- javac BattleboardGame.java
	
To run:
	- java BattleboardGame

4. We don't think it has any bug. It was running pretty well.