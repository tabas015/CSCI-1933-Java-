//Fahia Tabassum
// tabas015
// Roots Class

public class Roots{
  Complex4 root1;
  Complex4 root2;

  public Roots(Complex4 root1,Complex4 root2){
    this.root1 = root1;
    this.root2 = root2;
  }
  public String toString(){
    return "Roots are: " + root1 + " and, "  + " " + root2 + " " ;
  }
}
  